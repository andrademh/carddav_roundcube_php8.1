This migration enlarges the allowed size for the name of an addressbook.
