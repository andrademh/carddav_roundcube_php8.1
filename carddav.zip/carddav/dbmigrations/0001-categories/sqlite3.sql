ALTER TABLE TABLE_PREFIXcarddav_addressbooks ADD use_categories TINYINT NOT NULL DEFAULT 0;
