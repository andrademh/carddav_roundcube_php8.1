This migration has been disabled because it was broken. It got fixed and replaced by 0004-fixtimestampdefaultvalue.
