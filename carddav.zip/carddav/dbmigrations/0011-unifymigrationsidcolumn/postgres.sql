-- Postgres already had the ID column lowercase since the quotes are missing in original schema
SELECT * FROM TABLE_PREFIXcarddav_migrations; -- No migration
