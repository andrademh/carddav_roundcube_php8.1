This migration drops the authentication\_scheme field from the carddav\_addressbooks table, which is not used anymore.
